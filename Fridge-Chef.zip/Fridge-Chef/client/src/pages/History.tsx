import { useRecipes } from "@/hooks/use-recipes";
import { RecipeCard } from "@/components/RecipeCard";
import { RestaurantLayout } from "@/components/RestaurantLayout";
import { Loader2, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function History() {
  const { data: recipes, isLoading } = useRecipes();

  // Sort by newest first
  const sortedRecipes = recipes ? [...recipes].sort((a, b) => b.id - a.id) : [];

  return (
    <RestaurantLayout>
      <div className="space-y-8">
        <div className="flex items-center justify-between border-b border-primary/10 pb-6">
          <div>
            <Link href="/" className="inline-flex items-center gap-2 text-primary/60 hover:text-accent mb-2 font-serif font-medium transition-colors">
              <ArrowLeft className="w-4 h-4" />
              Back to Kitchen
            </Link>
            <h1 className="font-serif text-4xl font-bold text-primary">Menu Archive</h1>
            <p className="text-neutral-600 mt-2 font-sans">A collection of your past culinary creations.</p>
          </div>
          <div className="text-right hidden sm:block">
            <p className="font-serif font-bold text-3xl text-accent">{sortedRecipes.length}</p>
            <p className="text-xs uppercase tracking-widest text-primary/60">Recipes Created</p>
          </div>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-24">
            <Loader2 className="w-12 h-12 text-primary animate-spin" />
          </div>
        ) : sortedRecipes.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-8">
            {sortedRecipes.map((recipe) => (
              <RecipeCard key={recipe.id} recipe={recipe} />
            ))}
          </div>
        ) : (
          <div className="text-center py-24 bg-white/50 rounded-lg border-2 border-dashed border-primary/10">
            <h3 className="font-serif text-2xl text-primary mb-2">The Archive is Empty</h3>
            <p className="text-neutral-500 mb-6">You haven't generated any recipes yet.</p>
            <Link href="/" className="inline-flex items-center justify-center px-6 py-2 bg-primary text-primary-foreground font-serif font-bold rounded hover:bg-primary/90 transition-colors">
              Create Your First Recipe
            </Link>
          </div>
        )}
      </div>
    </RestaurantLayout>
  );
}
