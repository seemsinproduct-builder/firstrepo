import { useState } from "react";
import { useGenerateRecipe, useRecipes } from "@/hooks/use-recipes";
import { OrderPad } from "@/components/OrderPad";
import { RecipeCard } from "@/components/RecipeCard";
import { RestaurantLayout } from "@/components/RestaurantLayout";
import { motion } from "framer-motion";
import { Sparkles, Utensils } from "lucide-react";
import { Link } from "wouter";
import { VintageButton } from "@/components/VintageButton";

export default function Home() {
  const [showOrderPad, setShowOrderPad] = useState(true);
  const generateMutation = useGenerateRecipe();
  
  // We'll show the latest generated recipe if available
  // In a real app we might store this in local state or URL param
  const { data: recipes, isLoading: isLoadingHistory } = useRecipes();
  
  // Sort by ID descending to get latest first
  const latestRecipe = recipes?.sort((a, b) => b.id - a.id)[0];

  const handleGenerate = async (ingredients: string[]) => {
    try {
      await generateMutation.mutateAsync({ ingredients });
      setShowOrderPad(false);
    } catch (error) {
      // Error handled in hook
    }
  };

  return (
    <RestaurantLayout>
      <div className="grid lg:grid-cols-12 gap-12 items-start">
        {/* Left Column: Introduction & History Preview */}
        <div className="lg:col-span-4 space-y-8 order-2 lg:order-1">
          <div className="bg-white p-6 rounded-sm paper-shadow border border-neutral-200">
            <h2 className="font-serif text-2xl font-bold text-primary mb-4 flex items-center gap-2">
              <Utensils className="w-5 h-5 text-accent" />
              Kitchen Rules
            </h2>
            <p className="text-neutral-600 mb-4 leading-relaxed font-sans text-sm">
              Welcome to our digital kitchen. Tell our AI Chef what ingredients you have in your pantry, and we'll craft a bespoke recipe just for you.
            </p>
            <ul className="space-y-2 text-sm text-neutral-600 font-serif italic">
              <li className="flex gap-2"><span>1.</span> List your available ingredients</li>
              <li className="flex gap-2"><span>2.</span> Wait for the chef's inspiration</li>
              <li className="flex gap-2"><span>3.</span> Cook something magnificent</li>
            </ul>
          </div>

          <div className="bg-[#fffdf5] p-6 rounded-sm paper-shadow border border-neutral-200">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-serif text-xl font-bold text-primary">Recent Orders</h3>
              <Link href="/history" className="text-xs font-bold text-accent hover:underline uppercase tracking-wider">View All</Link>
            </div>
            
            {isLoadingHistory ? (
              <div className="space-y-3">
                {[1, 2, 3].map(i => (
                  <div key={i} className="h-16 bg-neutral-100 animate-pulse rounded" />
                ))}
              </div>
            ) : recipes && recipes.length > 0 ? (
              <div className="space-y-4">
                {recipes.slice(0, 3).map(recipe => (
                  <div key={recipe.id} className="group border-b border-dashed border-primary/20 pb-3 last:border-0 last:pb-0">
                    <h4 className="font-serif font-semibold text-primary group-hover:text-accent transition-colors truncate">
                      {recipe.name}
                    </h4>
                    <p className="text-xs text-neutral-500 mt-1 truncate font-sans">
                      {recipe.cookingTime} • {recipe.difficulty}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-neutral-500 italic">No recipes yet.</p>
            )}
          </div>
        </div>

        {/* Center/Right: Main Action Area */}
        <div className="lg:col-span-8 order-1 lg:order-2">
          {generateMutation.isPending ? (
            <div className="min-h-[600px] flex flex-col items-center justify-center text-center p-8 bg-white paper-shadow rounded-sm border border-neutral-200">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                className="mb-8"
              >
                <div className="w-24 h-24 border-4 border-accent border-t-transparent rounded-full" />
              </motion.div>
              <h2 className="font-serif text-3xl font-bold text-primary mb-2">The Chef is Thinking...</h2>
              <p className="font-serif italic text-xl text-neutral-500 max-w-md">
                "Consulting the grand library of flavors and techniques to match your ingredients."
              </p>
            </div>
          ) : showOrderPad ? (
            <div className="flex flex-col items-center">
              <div className="mb-8 text-center max-w-2xl">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="inline-block mb-3"
                >
                  <Sparkles className="w-8 h-8 text-accent mx-auto mb-2" />
                  <h1 className="font-serif text-4xl md:text-5xl font-bold text-primary mb-3">
                    What's in your pantry?
                  </h1>
                  <p className="text-lg text-neutral-600 font-sans">
                    Let's turn your leftovers into a gourmet experience.
                  </p>
                </motion.div>
              </div>
              <OrderPad onGenerate={handleGenerate} isGenerating={generateMutation.isPending} />
            </div>
          ) : latestRecipe ? (
            <div className="space-y-8">
              <div className="flex justify-between items-center mb-4">
                <h2 className="font-serif text-2xl text-primary font-bold">Your Result</h2>
                <VintageButton variant="outline" onClick={() => setShowOrderPad(true)} className="text-sm">
                  Create Another
                </VintageButton>
              </div>
              <RecipeCard recipe={latestRecipe} featured />
            </div>
          ) : (
            // Fallback if mutation finished but no recipe (shouldn't happen)
            <div className="text-center p-12">
               <p>Something went wrong. Please try again.</p>
               <VintageButton onClick={() => setShowOrderPad(true)} className="mt-4">
                 Try Again
               </VintageButton>
            </div>
          )}
        </div>
      </div>
    </RestaurantLayout>
  );
}
