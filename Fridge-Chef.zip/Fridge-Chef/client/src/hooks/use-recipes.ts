import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type GenerateRecipeRequest } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useRecipes() {
  return useQuery({
    queryKey: [api.recipes.list.path],
    queryFn: async () => {
      const res = await fetch(api.recipes.list.path);
      if (!res.ok) throw new Error("Failed to fetch recipes");
      return api.recipes.list.responses[200].parse(await res.json());
    },
  });
}

export function useGenerateRecipe() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: GenerateRecipeRequest) => {
      const res = await fetch(api.recipes.generate.path, {
        method: api.recipes.generate.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        // Try to parse error message if available
        try {
          const errorData = await res.json();
          throw new Error(errorData.message || "Failed to generate recipe");
        } catch {
          throw new Error("Failed to generate recipe");
        }
      }

      return api.recipes.generate.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.recipes.list.path] });
      toast({
        title: "Order Up!",
        description: "Your special dish has been prepared by the chef.",
      });
    },
    onError: (error) => {
      toast({
        title: "Kitchen Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
