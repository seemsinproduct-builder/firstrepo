import { UtensilsCrossed } from "lucide-react";
import { Link } from "wouter";

export function RestaurantLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      {/* Decorative Border Frame */}
      <div className="fixed inset-4 pointer-events-none z-50 border-double border-4 border-primary/10 rounded-lg hidden md:block" />
      
      {/* Header */}
      <header className="relative z-40 bg-white/80 backdrop-blur-sm border-b border-primary/10 sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <Link href="/" className="group flex items-center gap-3">
            <div className="p-2 bg-primary text-primary-foreground rounded-full group-hover:scale-110 transition-transform duration-300">
              <UtensilsCrossed className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-serif font-bold text-2xl tracking-tighter text-primary">Le Chef AI</h1>
              <p className="text-xs uppercase tracking-widest text-accent font-medium">Est. 2025</p>
            </div>
          </Link>

          <nav className="flex gap-6">
            <Link href="/" className="font-serif font-semibold text-primary/60 hover:text-primary transition-colors">Today's Special</Link>
            <Link href="/history" className="font-serif font-semibold text-primary/60 hover:text-primary transition-colors">Menu Archive</Link>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 relative z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {children}
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-30 py-8 text-center border-t border-primary/10 bg-white/50">
        <p className="font-serif italic text-primary/60 text-sm">
          "Cooking is like love. It should be entered into with abandon or not at all."
        </p>
        <div className="mt-4 flex justify-center gap-2">
           <span className="text-accent">★</span>
           <span className="text-accent">★</span>
           <span className="text-accent">★</span>
        </div>
      </footer>
    </div>
  );
}
