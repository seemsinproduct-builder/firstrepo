import { motion } from "framer-motion";
import { Clock, BarChart, Tag, ChefHat, Star } from "lucide-react";
import type { Recipe } from "@shared/schema";
import { cn } from "@/lib/utils";

interface RecipeCardProps {
  recipe: Recipe;
  featured?: boolean;
}

export function RecipeCard({ recipe, featured = false }: RecipeCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "relative bg-white p-8 rounded-sm paper-shadow border border-neutral-200 overflow-hidden group hover:border-accent/30 transition-colors",
        featured ? "md:col-span-2 bg-[#fffdf5]" : ""
      )}
    >
      {/* Decorative Corner */}
      <div className="absolute top-0 right-0 w-16 h-16 pointer-events-none overflow-hidden">
        <div className="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 rotate-45 w-16 h-16 bg-primary/5 group-hover:bg-accent/10 transition-colors" />
      </div>

      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="mb-6 border-b border-primary/10 pb-4">
          <div className="flex justify-between items-start gap-4">
            <h3 className={cn(
              "font-serif font-bold text-primary leading-tight",
              featured ? "text-3xl md:text-4xl" : "text-2xl"
            )}>
              {recipe.name}
            </h3>
            {featured && (
              <div className="bg-accent text-accent-foreground px-3 py-1 text-xs font-bold uppercase tracking-widest rounded-full shadow-sm">
                Chef's Special
              </div>
            )}
          </div>
          
          <div className="flex items-center gap-4 mt-3 text-sm text-neutral-600 font-medium font-sans">
            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-accent" />
              {recipe.cookingTime}
            </div>
            <div className="flex items-center gap-1.5">
              <BarChart className="w-4 h-4 text-accent" />
              {recipe.difficulty}
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="space-y-6 flex-grow">
          <p className="text-neutral-600 leading-relaxed italic font-serif border-l-2 border-accent/20 pl-4">
            "{recipe.description}"
          </p>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h4 className="font-serif font-bold text-primary text-lg flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                Ingredients
              </h4>
              <ul className="space-y-1.5">
                {recipe.ingredients.map((ing, i) => (
                  <li key={i} className="text-sm text-neutral-700 flex items-start gap-2">
                    <span className="font-serif text-accent/50 text-xs mt-1">❖</span>
                    {ing}
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-3">
              <h4 className="font-serif font-bold text-primary text-lg flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                Preparation
              </h4>
              <ol className="space-y-3">
                {recipe.steps.map((step, i) => (
                  <li key={i} className="text-sm text-neutral-700 flex gap-3">
                    <span className="font-serif font-bold text-primary/40 shrink-0">{i + 1}.</span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>

        {/* Footer */}
        {recipe.tags && recipe.tags.length > 0 && (
          <div className="mt-8 pt-4 border-t border-primary/10 flex flex-wrap gap-2">
            {recipe.tags.map((tag) => (
              <span key={tag} className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-neutral-100 text-neutral-600 text-xs font-medium border border-neutral-200">
                <Tag className="w-3 h-3" />
                {tag}
              </span>
            ))}
          </div>
        )}
      </div>
    </motion.div>
  );
}
