import { useState } from "react";
import { Plus, X, ChefHat, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { VintageButton } from "./VintageButton";
import { cn } from "@/lib/utils";

interface OrderPadProps {
  onGenerate: (ingredients: string[]) => void;
  isGenerating: boolean;
}

export function OrderPad({ onGenerate, isGenerating }: OrderPadProps) {
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [currentInput, setCurrentInput] = useState("");

  const handleAdd = () => {
    if (currentInput.trim()) {
      setIngredients([...ingredients, currentInput.trim()]);
      setCurrentInput("");
    }
  };

  const handleRemove = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index));
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      handleAdd();
    }
  };

  return (
    <div className="relative w-full max-w-md mx-auto perspective-1000">
      {/* Pad Binding */}
      <div className="absolute top-0 left-0 right-0 h-12 bg-neutral-800 rounded-t-lg z-20 flex items-center justify-center border-b-4 border-neutral-900 shadow-xl">
        <div className="w-3/4 h-full border-x-2 border-neutral-700 flex items-center justify-around px-4">
           {/* Spirals */}
           {[...Array(6)].map((_, i) => (
             <div key={i} className="w-3 h-3 rounded-full bg-neutral-400 shadow-inner ring-1 ring-neutral-950" />
           ))}
        </div>
      </div>

      {/* Paper Stack Effect */}
      <div className="absolute top-2 left-1 right-1 h-full bg-white rounded-lg shadow-sm transform rotate-1 z-0" />
      <div className="absolute top-1 left-0.5 right-0.5 h-full bg-white rounded-lg shadow-sm transform -rotate-1 z-0" />

      {/* Main Sheet */}
      <div className="relative bg-[#fdfbf7] p-8 pt-16 rounded-b-lg shadow-2xl min-h-[500px] flex flex-col z-10 border border-neutral-200">
        <div className="text-center mb-6 border-b-2 border-double border-primary/20 pb-4">
          <h2 className="font-serif text-3xl text-primary font-bold">The Pantry</h2>
          <p className="font-handwriting text-neutral-500 mt-1">What ingredients do we have today?</p>
        </div>

        {/* Lines Background */}
        <div className="absolute inset-0 top-32 pointer-events-none" 
             style={{ 
               backgroundImage: "repeating-linear-gradient(transparent, transparent 39px, #a8a29e 40px)",
               backgroundAttachment: "local" 
             }} 
        />

        <div className="relative z-10 flex-1 space-y-2 mb-8">
          <AnimatePresence>
            {ingredients.map((ing, i) => (
              <motion.div
                key={`${ing}-${i}`}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="flex items-center justify-between group h-10 px-2"
              >
                <span className="font-handwriting text-xl text-primary/80 truncate w-full flex items-center gap-2">
                  <span className="text-sm opacity-50 font-sans select-none">{i + 1}.</span> {ing}
                </span>
                <button
                  onClick={() => handleRemove(i)}
                  className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-700 transition-opacity"
                >
                  <X className="w-5 h-5" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Input Line */}
          <div className="flex items-center gap-2 h-10 px-2">
            <span className="font-handwriting text-xl text-primary/40 select-none">{ingredients.length + 1}.</span>
            <input
              type="text"
              value={currentInput}
              onChange={(e) => setCurrentInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Add ingredient..."
              className="flex-1 bg-transparent border-none focus:ring-0 font-handwriting text-xl text-primary placeholder:text-primary/30 p-0"
              autoFocus
            />
            <button 
              onClick={handleAdd}
              disabled={!currentInput.trim()}
              className="text-primary hover:text-accent disabled:opacity-30 transition-colors"
            >
              <Plus className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="relative z-20 mt-auto pt-6 border-t-2 border-double border-primary/20 text-center space-y-4">
          <p className="font-serif italic text-sm text-neutral-500">
            {ingredients.length === 0 
              ? "List is empty, Chef." 
              : `${ingredients.length} items ready for prep.`}
          </p>
          
          <VintageButton 
            onClick={() => onGenerate(ingredients)}
            isLoading={isGenerating}
            disabled={ingredients.length === 0}
            className="w-full"
            variant="secondary"
          >
            {isGenerating ? "Consulting Chef..." : (
              <>
                <ChefHat className="w-5 h-5" />
                <span>Create Recipe</span>
              </>
            )}
          </VintageButton>
        </div>
      </div>
    </div>
  );
}
