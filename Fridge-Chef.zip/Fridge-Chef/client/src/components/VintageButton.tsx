import { ButtonHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

interface VintageButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "outline";
  isLoading?: boolean;
}

export const VintageButton = forwardRef<HTMLButtonElement, VintageButtonProps>(
  ({ className, variant = "primary", isLoading, children, ...props }, ref) => {
    const baseStyles = "relative inline-flex items-center justify-center px-8 py-3 overflow-hidden font-serif font-bold tracking-wider transition-all duration-300 ease-out group disabled:opacity-70 disabled:pointer-events-none";
    
    const variants = {
      primary: "bg-primary text-primary-foreground shadow-md hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0",
      secondary: "bg-accent text-accent-foreground shadow-md hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0",
      outline: "bg-transparent border-2 border-primary text-primary hover:bg-primary/5",
    };

    return (
      <button
        ref={ref}
        className={cn(baseStyles, variants[variant], className)}
        disabled={isLoading || props.disabled}
        {...props}
      >
        <span className={cn("absolute w-0 h-0 transition-all duration-500 ease-out bg-white rounded-full group-hover:w-56 group-hover:h-56 opacity-10")} />
        
        {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
        <span className="relative flex items-center gap-2">
          {children}
        </span>
      </button>
    );
  }
);

VintageButton.displayName = "VintageButton";
