## Packages
framer-motion | Animations for the menu opening, cards flipping, and lists appearing
lucide-react | Icons for the UI (already in base but good to note usage)
clsx | Utility for conditional class names
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  serif: ["'Playfair Display'", "serif"],
  sans: ["'DM Sans'", "sans-serif"],
  handwriting: ["'Architects Daughter'", "cursive"], // Good for the "order pad" look
  display: ["'Playfair Display'", "serif"],
}
