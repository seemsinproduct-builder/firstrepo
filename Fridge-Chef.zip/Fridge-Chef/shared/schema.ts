import { pgTable, text, serial, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const recipes = pgTable("recipes", {
  id: serial("id").primaryKey(),
  ingredients: text("ingredients").array().notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  steps: text("steps").array().notNull(),
  cookingTime: text("cooking_time").notNull(), // e.g., "30 mins"
  difficulty: text("difficulty").notNull(), // "Easy", "Medium", "Hard"
  tags: text("tags").array(), // e.g., "Vegetarian", "Spicy"
});

export const insertRecipeSchema = createInsertSchema(recipes).omit({ id: true });

export type InsertRecipe = z.infer<typeof insertRecipeSchema>;
export type Recipe = typeof recipes.$inferSelect;

// For the AI generation request
export const generateRecipeSchema = z.object({
  ingredients: z.array(z.string()).min(1),
  dietaryRestrictions: z.string().optional(),
});

export type GenerateRecipeRequest = z.infer<typeof generateRecipeSchema>;
