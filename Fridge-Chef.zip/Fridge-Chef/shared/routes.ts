import { z } from "zod";
import { insertRecipeSchema, generateRecipeSchema, recipes } from "./schema";

export const api = {
  recipes: {
    generate: {
      method: "POST" as const,
      path: "/api/recipes/generate",
      input: generateRecipeSchema,
      responses: {
        200: z.object({
          recipe: z.custom<typeof recipes.$inferSelect>(),
        }),
        500: z.object({ message: z.string() }),
      },
    },
    list: {
        method: "GET" as const,
        path: "/api/recipes",
        responses: {
            200: z.array(z.custom<typeof recipes.$inferSelect>()),
        }
    }
  },
};
