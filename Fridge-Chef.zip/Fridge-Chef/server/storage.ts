import { db } from "./db";
import { recipes, type InsertRecipe, type Recipe } from "@shared/schema";

export interface IStorage {
    createRecipe(recipe: InsertRecipe): Promise<Recipe>;
    getRecipes(): Promise<Recipe[]>;
}

export class DatabaseStorage implements IStorage {
    async createRecipe(recipe: InsertRecipe): Promise<Recipe> {
        const [newRecipe] = await db.insert(recipes).values(recipe).returning();
        return newRecipe;
    }

    async getRecipes(): Promise<Recipe[]> {
        return await db.select().from(recipes);
    }
}

export const storage = new DatabaseStorage();
