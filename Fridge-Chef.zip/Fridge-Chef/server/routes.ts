import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { generateRecipeSchema } from "@shared/schema";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  app.post(api.recipes.generate.path, async (req, res) => {
    try {
        const input = generateRecipeSchema.parse(req.body);

        const prompt = `Generate a creative recipe using the following ingredients: ${input.ingredients.join(", ")}. ${input.dietaryRestrictions ? `Dietary restrictions: ${input.dietaryRestrictions}.` : ""}
        
        The response must be valid JSON matching this schema:
        {
            "name": "Recipe Name",
            "description": "Short description",
            "ingredients": ["ingredient 1", "ingredient 2"],
            "steps": ["Step 1", "Step 2"],
            "cookingTime": "30 mins",
            "difficulty": "Medium",
            "tags": ["Tag1", "Tag2"]
        }`;

        const response = await openai.chat.completions.create({
            model: "gpt-5.1",
            messages: [{ role: "user", content: prompt }],
            response_format: { type: "json_object" },
        });

        const content = response.choices[0].message.content;
        if (!content) {
            throw new Error("Failed to generate recipe");
        }

        const generatedRecipe = JSON.parse(content);
        
        // Save to DB
        const savedRecipe = await storage.createRecipe({
            name: generatedRecipe.name,
            description: generatedRecipe.description,
            ingredients: generatedRecipe.ingredients,
            steps: generatedRecipe.steps,
            cookingTime: generatedRecipe.cookingTime,
            difficulty: generatedRecipe.difficulty,
            tags: generatedRecipe.tags || [],
        });

        res.json({ recipe: savedRecipe });

    } catch (error) {
        console.error("Recipe generation error:", error);
        res.status(500).json({ message: "Failed to generate recipe" });
    }
  });

  app.get(api.recipes.list.path, async (req, res) => {
      const recipes = await storage.getRecipes();
      res.json(recipes);
  });

  return httpServer;
}
